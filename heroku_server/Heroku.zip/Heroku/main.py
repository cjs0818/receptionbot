# -*- coding: utf-8 -*-

# ----------------------------------------
# Web server file which is used in Heroku
#
#   In 'Procfile", you need to write the following sentence:
#       web: gunicorn main:app
#
#   Then, everytime you modify this main.py, your Heroku server should be updated, by typing
#       git push heroku master
# ----------------------------------------

import requests
import json

from PIL import Image
from io import BytesIO
from flask import Flask, request, make_response, jsonify
import csv



ERROR_MESSAGE           = '네트워크 접속에 문제가 발생하였습니다. 잠시 후 다시 시도해주세요.'
URL_OPEN_TIME_OUT       = 10



app = Flask(__name__)


# ----------------------------------------------------
# 사진 구함
# ----------------------------------------------------
def get_photo(answer):
    photo = ''
    index = answer.find('</Photo>')

    if index >= 0:
        photo = answer[len('<Photo>'):index]
        answer = answer[index + len('</Photo>'):]

    return answer, photo


# ----------------------------------------------------
# 사진 크기 구함
# ----------------------------------------------------
def get_photo_size(url):
    width = 0
    height = 0

    if url == '':
        return width, height

    try:
        data = requests.get(url).content
        im = Image.open(BytesIO(data))

        width = im.size[0]
        height = im.size[1]
    except:
        print('get_photo_size error')

    return width, height


# ----------------------------------------------------
# 메뉴 구함
# ----------------------------------------------------
def get_menu(answer):
    # --------------------------------
    # 메뉴가 있는지 검사
    # --------------------------------
    menu = []
    index = answer.find(' 1. ')

    if index < 0:
        return answer, menu

    menu_string = answer[index + 1:]
    answer = answer[:index]

    # --------------------------------
    # 메뉴를 배열로 설정
    # --------------------------------
    number = 1

    while 1:
        number += 1
        search_string = ' %d. ' % number
        index = menu_string.find(search_string)

        if index < 0:
            menu.append(menu_string[3:].strip())
            break;

        menu.append(menu_string[3:index].strip())
        menu_string = menu_string[index + 1:]

    return answer, menu


# ----------------------------------------------------
# 메뉴 버튼 구함
# ----------------------------------------------------
def get_menu_button(menu):
    if len(menu) == 0:
        return None

    menu_button = {
        'type': 'buttons',
        'buttons': menu
    }

    return menu_button


# ----------------------------------------------------
# Dialogflow에서 대답 구함
# ----------------------------------------------------
def get_answer(text, user_key):
    # --------------------------------
    # Dialogflow에 요청
    # --------------------------------
    data_send = {
        'lang': 'ko',
        'query': text,
        'sessionId': user_key,
        'timezone': 'Asia/Seoul'
    }

    data_header = {
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': 'Bearer 9d10041bdb9c4c68a88b7899ca1540c1'  # Dialogflow의 Client access token 입력
    }

    dialogflow_url = 'https://api.dialogflow.com/v1/query?v=20150910'


    res = requests.post(dialogflow_url,
                        data=json.dumps(data_send),
                        headers=data_header)

    # --------------------------------
    # 대답 처리
    # --------------------------------
    if res.status_code != requests.codes.ok:
        return ERROR_MESSAGE

    data_receive = res.json()
    answer = data_receive['result']['fulfillment']['speech']

    return answer


#----------------------------------------------------
# 카카오톡 키보드 처리
#----------------------------------------------------
@app.route("/keyboard")
def keyboard():

    res = {
        'type': 'buttons',
        'buttons': ['대화하기']
    }

    return jsonify(res)


# ----------------------------------------------------
# 카카오톡 메시지 처리
# ----------------------------------------------------
@app.route('/message', methods=['POST'])
def message():
    # --------------------------------
    # 메시지 받기
    # --------------------------------
    req = request.get_json()
    user_key = req['user_key']
    content = req['content']

    if len(user_key) <= 0 or len(content) <= 0:
        answer = ERROR_MESSAGE

    # --------------------------------
    # 답변 구함
    # --------------------------------
    if content == u'대화하기':
        answer = '안녕하세요! 전 안내를 담당하는 챗봇입니다~'
    else:
        answer = get_answer(content, user_key)

    # --------------------------------
    # 사진 구함
    # --------------------------------
    answer, photo = get_photo(answer)
    photo_width, photo_height = get_photo_size(photo)

    # --------------------------------
    # 메뉴 구함
    # --------------------------------
    answer, menu = get_menu(answer)

    # --------------------------------
    # 메시지 설정
    # --------------------------------
    res = {
        'message': {
            'text': answer
        }
    }

    # --------------------------------
    # 사진 설정
    # --------------------------------
    if photo != '' and photo_width > 0 and photo_height > 0:
        res['message']['photo'] = {
            'url': photo,
            'width': photo_width,
            'height': photo_height
        }

    # --------------------------------
    # 메뉴 버튼 설정
    # --------------------------------
    menu_button = get_menu_button(menu)

    if menu_button != None:
        res['keyboard'] = menu_button

    return jsonify(res)


# ----------------------------------------------------
# database from CSV file
# ----------------------------------------------------
def get_datatbase(kind_of_guide):
    filename = 'RMI_researchers.csv'

    try:
        with open(filename, 'r', encoding='UTF-8-sig') as f:
            csv_data = csv.reader(f, delimiter=',')
            print("-------------")
            dict = {}
            row_cnt = 0
            for row in csv_data:
                row_cnt = row_cnt + 1
                if row_cnt == 1:
                    key = row
                else:
                    for i in range(0, len(row), 1):
                        if i == 0:
                            # print(dict_name)
                            dict_info = {}
                        else:
                            dict_info.update({key[i]: row[i]})
                            # print(dict_info)
                    dict.update({row[0]: dict_info})
                    # print("dict_name = ", dict_name)
    except:
        dict = 'ERROR'

    #json_data = json.dumps(dict, indent=4, ensure_ascii=False)
    #print(json_data)

    return dict


# ----------------------------------------------------
# 카카오톡 메시지 처리
# ----------------------------------------------------
@app.route('/message_danbee', methods=['POST'])
def message_danbee():
    # --------------------------------
    # 메시지 받기
    # --------------------------------
    req = request.get_json()
    #req = request.json()

    name = req['name']

    #if len(user_key) <= 0 or len(content) <= 0:
    #    answer = ERROR_MESSAGE

    kind_of_guide = 'person'
    db = get_datatbase(kind_of_guide)


    # --------------------------------
    # 메시지 설정
    # --------------------------------
    try:
        info = db[name]
        # print('   information about ', name, ': ', json.dumps(info, indent=4, ensure_ascii=False))
    except:
        print('죄송합니다만, KIST 국제협력관에서 ', name, '님의 정보를 찾을 수 없습니다.')
        info = 'ERROR'

    answer = {
        'name': name,
        'information': info
    }
    print(json.dumps(answer, indent=4, ensure_ascii=False))
    '''
    answer = {
        name: {
            'center': '지능로봇연구단',
            'room#': '8402',
            'phone#': '5618',
            'e-mail': 'cjs@kist.re.kr'
        }
    }
    '''
    res = {
        'message': {
            'text': answer
        }
    }

    return jsonify(res)


#----------------------------------------------------
# 메인 함수
#----------------------------------------------------
if __name__ == '__main__':

    app.run(host='0.0.0.0', threaded=True)
